Astraliva JWT Lab - Modular Flask App
-------------------------------------
Run locally:
  pip install -r requirements.txt
  python app.py
Then open http://127.0.0.1:5000

Features:
- L1: Orders (missing signature verification -> IDOR)
- L2: Account (accepts alg:none)
- L3: Admin (algorithm confusion RS256 <-> HS256)