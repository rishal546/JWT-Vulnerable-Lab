from flask import Flask
from astraliva.routes import home, auth, l1, l2, l3, debug

def create_app():
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config.from_object("astraliva.config")
    app.secret_key = app.config.get("FLASK_SECRET")
    # register blueprints
    app.register_blueprint(home.bp)
    app.register_blueprint(auth.bp)
    app.register_blueprint(l1.bp)
    app.register_blueprint(l2.bp)
    app.register_blueprint(l3.bp)
    app.register_blueprint(debug.bp)
    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, port=5000)