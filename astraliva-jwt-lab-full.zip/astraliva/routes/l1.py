from flask import Blueprint, render_template, request
from astraliva.utils.jwt_utils import decode_jwt_parts
from astraliva.data import USERS

bp = Blueprint('l1', __name__, url_prefix='/l1')

@bp.route('/orders')
def orders():
    token = request.cookies.get('auth') or (request.headers.get('Authorization') or '').replace('Bearer ','')
    if not token:
        return render_template('orders_l1.html', error='No token provided. Login via /auth/login/l1')
    try:
        header,payload,sig = decode_jwt_parts(token)
    except Exception as e:
        return render_template('orders_l1.html', error='Invalid token format')
    # intentionally reject alg none on this endpoint
    if (header.get('alg') or '').lower() == 'none':
        return render_template('orders_l1.html', error='This endpoint rejects alg: none (try level 2)')
    sub = payload.get('sub')
    user = USERS.get(int(sub)) if sub else None
    if not user:
        return render_template('orders_l1.html', error='User not found for sub in token')
    # fake orders display
    orders = [
        f"Order #A-{user['id']}-001 · 2x Astraliva Perfume",
        f"Order #A-{user['id']}-002 · 1x Astraliva Gift Box"
    ]
    return render_template('orders_l1.html', user=user, orders=orders, header=header, payload=payload)