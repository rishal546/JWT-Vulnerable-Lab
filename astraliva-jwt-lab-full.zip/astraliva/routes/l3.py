from flask import Blueprint, render_template, request, current_app
from astraliva.utils.jwt_utils import decode_jwt_parts, hmac_sha256_b64url
from astraliva.data import USERS

bp = Blueprint('l3', __name__, url_prefix='/l3')

@bp.route('/admin')
def admin():
    token = request.cookies.get('auth') or (request.headers.get('Authorization') or '').replace('Bearer ','')
    if not token:
        return render_template('admin_l3.html', error='No token provided. Login via /auth/login/l3')
    try:
        header,payload,sig = decode_jwt_parts(token)
    except Exception as e:
        return render_template('admin_l3.html', error='Invalid token format')
    alg = (header.get('alg') or '').upper()
    signing_input = token.split('.')[0] + '.' + token.split('.')[1]
    if alg == 'RS256':
        # server issued RS256 tokens (simulated HMAC with RSA_PRIVATE)
        expected = hmac_sha256_b64url(current_app.config['RSA_PRIVATE'], signing_input)
        if sig != expected:
            return render_template('admin_l3.html', error='RS256 signature invalid')
        uid = int(payload.get('sub'))
        user = USERS.get(uid)
        if not user:
            return render_template('admin_l3.html', error='User not found')
        if user.get('role') == 'admin' or payload.get('role') == 'admin' or uid == 9001:
            return render_template('admin_l3.html', user=user, header=header, payload=payload, note='RS256 validated')
        return render_template('admin_l3.html', error='Not an admin')
    elif alg == 'HS256':
        # vulnerable: server will verify HS256 using RSA_PUBLIC as HMAC secret
        expected = hmac_sha256_b64url(current_app.config['RSA_PUBLIC'], signing_input)
        if sig != expected:
            return render_template('admin_l3.html', error='HS256 signature invalid when checked with public key')
        uid = int(payload.get('sub'))
        user = USERS.get(uid)
        if not user:
            return render_template('admin_l3.html', error='User not found')
        if payload.get('role') == 'admin' or uid == 9001 or user.get('role') == 'admin':
            return render_template('admin_l3.html', user=user, header=header, payload=payload, note='HS256 verified with public key (vulnerable)')
        return render_template('admin_l3.html', error='Not an admin')
    else:
        return render_template('admin_l3.html', error='Unsupported algorithm')