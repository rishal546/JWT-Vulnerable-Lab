from flask import Blueprint, render_template, request, current_app
from astraliva.utils.jwt_utils import decode_jwt_parts, hmac_sha256_b64url
from astraliva.data import USERS

bp = Blueprint('l2', __name__, url_prefix='/l2')

@bp.route('/account')
def account():
    token = request.cookies.get('auth') or (request.headers.get('Authorization') or '').replace('Bearer ','')
    if not token:
        return render_template('account_l2.html', error='No token provided. Login via /auth/login/l2')
    try:
        header,payload,sig = decode_jwt_parts(token)
    except Exception as e:
        return render_template('account_l2.html', error='Invalid token format')
    # vulnerable: accept alg none unsigned tokens
    if (header.get('alg') or '').lower() == 'none':
        user = USERS.get(int(payload.get('sub'))) if payload.get('sub') else None
        if not user:
            return render_template('account_l2.html', error='User not found in unsigned token')
        return render_template('account_l2.html', user=payload, header=header, payload=payload, note='Unsigned token accepted')
    # otherwise verify HS256 using LVL2_SECRET
    parts = token.split('.')
    if len(parts) < 3:
        return render_template('account_l2.html', error='Token signature missing and alg != none')
    signing_input = parts[0] + '.' + parts[1]
    expected_sig = hmac_sha256_b64url(current_app.config['LVL2_SECRET'], signing_input)
    if parts[2] != expected_sig:
        return render_template('account_l2.html', error='Invalid signature (HS256 verification failed)')
    # signature ok
    user = USERS.get(int(payload.get('sub'))) if payload.get('sub') else None
    if not user:
        return render_template('account_l2.html', error='User not found')
    return render_template('account_l2.html', user=user, header=header, payload=payload)