from flask import Blueprint, request
from astraliva.utils.jwt_utils import decode_jwt_parts

bp = Blueprint('debug', __name__, url_prefix='/debug')

@bp.route('/decode', methods=['GET'])
def decode():
    token = request.args.get('token') or request.cookies.get('auth') or ''
    if not token:
        return "No token provided (pass token as ?token= or use auth cookie)", 400
    try:
        header,payload,sig = decode_jwt_parts(token)
        return f"Header:\n{header}\n\nPayload:\n{payload}\n\nSignature:\n{sig or '<empty>'}"
    except Exception as e:
        return f"Invalid token: {e}", 400