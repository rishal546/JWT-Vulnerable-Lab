from flask import Blueprint, render_template, request, redirect, url_for, make_response, current_app
from astraliva.utils.jwt_utils import create_jwt
from astraliva.data import USERS
import json

bp = Blueprint('auth', __name__, url_prefix='/auth')

@bp.route('/login/<level>', methods=['GET','POST'])
def login(level):
    # level is 'l1','l2','l3'
    if request.method == 'GET':
        return render_template('login.html', level=level.upper())
    # process login (no password checks - demo)
    uid = int(request.form.get('uid') or 1001)
    user = USERS.get(uid)
    if not user:
        return "Unknown user", 400
    # create tokens according to level
    if level == 'l1':
        header = {'alg':'HS256','typ':'JWT'}
        payload = {'sub': user['id'], 'username': user['username'], 'email': user['email']}
        token = create_jwt(header,payload,current_app.config['LVL1_SECRET'])
    elif level == 'l2':
        header = {'alg':'HS256','typ':'JWT'}
        payload = {'sub': user['id'], 'username': user['username'], 'email': user['email']}
        token = create_jwt(header,payload,current_app.config['LVL2_SECRET'])
    elif level == 'l3':
        header = {'alg':'RS256','typ':'JWT'}
        payload = {'sub': user['id'], 'username': user['username'], 'email': user['email']}
        # server "signs" RS256 using RSA_PRIVATE (simulated HMAC for lab)
        token = create_jwt(header,payload,current_app.config['RSA_PRIVATE'])
    else:
        return "Bad level", 400
    resp = make_response(render_template('display_token.html', token=token))
    resp.set_cookie('auth', token)
    return resp