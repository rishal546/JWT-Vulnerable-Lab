# Fake users & products
USERS = {
    1001: {'id':1001,'username':'alice','email':'alice@astraliva.test','role':'customer'},
    1002: {'id':1002,'username':'bob','email':'bob@astraliva.test','role':'customer'},
    9001: {'id':9001,'username':'admin','email':'admin@astraliva.test','role':'admin'},
}
PRODUCTS = [
    {'id':1,'name':'Astraliva Perfume (50ml)','price':29.99},
    {'id':2,'name':'Astraliva Candle','price':12.50},
    {'id':3,'name':'Astraliva Gift Box','price':45.00},
]