import base64, json, hmac, hashlib

def b64url_encode(data_bytes: bytes) -> str:
    return base64.urlsafe_b64encode(data_bytes).rstrip(b'=').decode()

def b64url_decode(s: str) -> bytes:
    padding = '=' * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + padding)

def json_b64url(obj) -> str:
    return b64url_encode(json.dumps(obj, separators=(',', ':')).encode())

def hmac_sha256_b64url(key_str: str, signing_input: str) -> str:
    sig = hmac.new(key_str.encode(), signing_input.encode(), hashlib.sha256).digest()
    return b64url_encode(sig)

def create_jwt(header: dict, payload: dict, key_for_sig: str):
    header_b = json_b64url(header)
    payload_b = json_b64url(payload)
    signing_input = f"{header_b}.{payload_b}"
    alg = (header.get('alg') or '').upper()
    if alg == 'NONE':
        return signing_input  # unsigned token (no signature)
    sig = hmac_sha256_b64url(key_for_sig, signing_input)
    return f"{signing_input}.{sig}"

def decode_jwt_parts(token: str):
    parts = token.split('.')
    if len(parts) < 2:
        raise ValueError("Token must have at least header and payload")
    header_json = json.loads(b64url_decode(parts[0]).decode())
    payload_json = json.loads(b64url_decode(parts[1]).decode())
    sig = parts[2] if len(parts) > 2 else ''
    return header_json, payload_json, sig